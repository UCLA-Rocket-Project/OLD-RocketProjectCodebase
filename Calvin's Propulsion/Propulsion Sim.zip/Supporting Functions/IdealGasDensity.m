function rho = IdealGasDensity(p,T,R)

rho = p/(R*T)*144;