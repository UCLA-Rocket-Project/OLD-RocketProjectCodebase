classdef Gas
    properties
        gam
        R
        G
        c_v
        c_p
        a
        b
    end
end
