classdef Liquid
    properties
        G
        rho
    end
end